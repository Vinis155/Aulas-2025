const API_URL = "/books";

async function loadBooks() {
    const res = await fetch(API_URL);
    const data = await res.json();
    const tbody = document.querySelector("#booksTable tbody");
    tbody.innerHTML = "";
    data.forEach(book => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
            <td>${book.id}</td>
            <td contenteditable="true" id="title-${book.id}">${book.title}</td>
            <td contenteditable="true" id="author-${book.id}">${book.author}</td>
            <td>
                <button class="btn edit" onclick="updateBook(${book.id})">Salvar</button>
                <button class="btn delete" onclick="deleteBook(${book.id})">Excluir</button>
            </td>`;
        tbody.appendChild(tr);
    });
}

async function addBook() {
    const title = document.getElementById("title").value;
    const author = document.getElementById("author").value;
    await fetch(API_URL, {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({title, author})
    });
    document.getElementById("title").value = "";
    document.getElementById("author").value = "";
    loadBooks();
}

async function updateBook(id) {
    const title = document.getElementById(`title-${id}`).innerText;
    const author = document.getElementById(`author-${id}`).innerText;
    await fetch(`${API_URL}/${id}`, {
        method: "PUT",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({title, author})
    });
    loadBooks();
}

async function deleteBook(id) {
    await fetch(`${API_URL}/${id}`, { method: "DELETE" });
    loadBooks();
}

loadBooks();
