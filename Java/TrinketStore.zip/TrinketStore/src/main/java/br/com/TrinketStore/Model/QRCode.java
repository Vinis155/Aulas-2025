package br.com.TrinketStore.Model;

public class QRCode {
}
