package br.com.TrinketStore.TrinketStore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrinketStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
